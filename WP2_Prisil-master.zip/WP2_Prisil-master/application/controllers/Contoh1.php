<?php 
class contoh1 extends CI_Controller
 { 
    public function index() 
    { 
        echo "<h1>Perkenalkan</h1>"; 
        echo"Nama saya Prisil saya tinggal di Pamulang
        olahraga yang saya sukai adalah Berenang"; 
    }
}