<section>
    <h1><?php echo $judul ?></h1>
    <h4>Nama</h4> <ul type="disc"> 
        <li>Nama Depan : Raisa</li> 
        <li>Nama Belakang : Priscilla</li> 
    </ul> 

    <h4>Alamat</h4> 
    <ul type="none"> 
        <li> Pamulang Permai</li> 
    </ul> 

    <h4>Tempat Lahir</h4>
    <ul type="none"> 
        <li>Kupang</li> 
    </ul> 

    <h4>Olahraga Favorit</h4> 
    <ul type="square">
        <li>Berenang</li> 
        <li>Drakoran sambil tiduran</li> 
    </ul> 
</section>